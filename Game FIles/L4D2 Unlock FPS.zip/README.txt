Left D-Pad shows FPS
Right D-Pad unlocks FPS

drop this in content\454108D4\00000001\UserSettings