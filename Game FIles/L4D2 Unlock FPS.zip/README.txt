Left or Right D-Pad btoh show FPS and Unlock the FPS

drop left4dead2_cfg_ss.cfg in your xenia folder

Credits to Parker