Left D-Pad shows FPS
Right D-Pad unlocks FPS

drop left4dead2_cfg_ss.cfg in your xenia folder